import './App.css';
import Todolist from './features/todolist/Todolist';

function App() {
    return (
        <div className='App'>
            <Todolist />
        </div>
    );
}

export default App;
