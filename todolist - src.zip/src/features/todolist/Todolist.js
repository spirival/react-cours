import { useState } from 'react';
import './Todolist.css';

import Todo from './Todo';
import AddTodo from './AddTodo';

export default function Todolist() {
    const [todoList, setTodoList] = useState([]);

    function addTodo() {
        setTodoList([
            ...todoList,
            {
                id:
                    todoList.reduce(
                        (maxId, { id }) => (maxId > id ? maxId : id),
                        0
                    ) + 1,
                title: '',
            },
        ]);
    }

    function deleteTodo(id) {
        setTodoList(todoList.filter((todo) => todo.id !== id));
    }

    function editTodo(id, title) {
        setTodoList(
            todoList.map((todo) => (todo.id === id ? { id, title } : todo))
        );
    }

    return (
        <table className='Todolist'>
            <thead>
                <AddTodo addTodo={addTodo} />
            </thead>
            <tbody>
                {todoList.map((todo) => (
                    <Todo
                        key={todo.id}
                        todo={todo}
                        deleteTodo={deleteTodo}
                        editTodo={editTodo}
                    />
                ))}
            </tbody>
        </table>
    );
}
