export default function Todo({ deleteTodo, editTodo, todo: { id, title } }) {
    return (
        <tr>
            <td>
                <input
                    type='text'
                    value={title}
                    onChange={(event) => editTodo(id, event.target.value)}
                />
            </td>
            <td className='deleteBtn' onClick={() => deleteTodo(id)}>
                x
            </td>
        </tr>
    );
}
