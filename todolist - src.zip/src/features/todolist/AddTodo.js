export default function AddTodo({ addTodo }) {
    return (
        <tr>
            <th colSpan='2'>
                <button onClick={addTodo}>Add todo</button>
            </th>
        </tr>
    );
}
